package tests;

import calculator.model.Calculator;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestCalculator {
    public void testOh(Calculator tester) {
        assertEquals(0.0, tester.displayNumber(),.01);
    }

    public void testNums(Calculator tester, double expected) {
        assertEquals(expected, tester.displayNumber(),.00001);
    }

    @Test
    public void testCalculator() {
        Calculator tester = new Calculator();
        testOh(tester);

        tester.numberPressed(4);
        tester.numberPressed(5);
        testNums(tester, 45.0);

        tester.dividePressed();
        tester.numberPressed(5);
        tester.equalsPressed();
        testNums(tester, 9.0);

        tester.multiplyPressed();
        tester.numberPressed(2);
        tester.equalsPressed();
        testNums(tester, 18.0);

        tester.addPressed();
        tester.numberPressed(2);
        tester.equalsPressed();
        testNums(tester, 20.0);

        tester.subtractPressed();
        tester.numberPressed(5);
        tester.equalsPressed();
        testNums(tester, 15.0);

        tester = new Calculator();
        tester.numberPressed(0);
        tester.numberPressed(1);
        tester.numberPressed(2);
        tester.numberPressed(3);
        tester.numberPressed(4);
        tester.numberPressed(5);
        tester.numberPressed(6);
        tester.numberPressed(7);
        tester.numberPressed(8);
        tester.numberPressed(9);
        testNums(tester, 0123456789.0);

    }

}
