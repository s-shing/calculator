package calculator.model;

import static java.lang.Double.parseDouble;

public class Calculator {

    public double num;
    private Case orig = new Case(this);

    public State state = this.orig;
    public void setOp(State state){this.state= state;}

    public Calculator(){
        this.num = 0.0;
    }

    // Accessed by View. You should edit this method as you build functionality
    public double displayNumber() {
        return this.orig.displayNumber();
    }

    public void clearPressed() {
        this.state.clearPressed();
    }

    public void numberPressed(int number) {
        this.state.numberPressed(number);
    }

    public void dividePressed() {
       setOp(new divide(orig));
    }

    public void multiplyPressed() {
        setOp(new multiply(orig));
    }

    public void subtractPressed() {
        setOp(new subtract(orig));
    }

    public void addPressed() {
        setOp(new add(orig));
    }

    public void equalsPressed() {
       this.state.equalsPressed();
    }

    public void decimalPressed() {
        // TODO
    }


}
