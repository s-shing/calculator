package calculator.model;

import static java.lang.Double.parseDouble;

public class numPressed implements State {
    private String num ="";
    private Case calc;

    public numPressed(Case calc, int number){
        this.calc = calc;
        num += number;
    }
    public double displayNumber() {
        return parseDouble(this.num);
    }
    public void clearPressed() {
        calc.setOp(calc);
    }

    public void equalsPressed() {

    }
@Override
    public void numberPressed(int number) {
        this.num += number;
        calc.num = displayNumber();
}
}
