package calculator.model;

public class Case implements State {

    public double num;
    public void setOp(State state){calc.state= state;}
    private Calculator calc;

    public Case(Calculator calc) {
        this.calc = calc;
        this.num = 0.0;
    }

    // Accessed by View. You should edit this method as you build functionality
    public double displayNumber() {
        return this.num;
    }

    public void clearPressed() {
        this.num = 0.0;
    }

    public void numberPressed(int number) {
        setOp(new numPressed(this,number));
        calc.num = this.num;
    }

    public void dividePressed() {
        setOp(new divide(this));
        calc.num = this.num;

    }

    public void multiplyPressed() {
        setOp(new multiply(this));
        calc.num = this.num;

    }

    public void subtractPressed() {
        setOp(new subtract(this));
        calc.num = this.num;

    }

    public void addPressed() {
        setOp(new add(this));
        calc.num = this.num;

    }

    public void equalsPressed() {
    }

    public void decimalPressed() {
        // TODO
    }


}

