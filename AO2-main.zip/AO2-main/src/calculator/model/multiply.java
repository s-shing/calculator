package calculator.model;

import static java.lang.Double.parseDouble;

public class multiply implements State{
    public double num;
    public State state;

    public void setOp(State state){this.state= state;}

    private Case calc;

    public multiply(Case calc){
        this.num = 0.0;
        this.calc = calc;
    }
    public double displayNumber() {
        return num;
    }

    public void clearPressed() {
        this.num = 0.0;
    }
    @Override
    public void equalsPressed() {
        calc.num =calc.displayNumber() * this.state.displayNumber();
    }
    public void numberPressed(int number) {
        setOp(new numPressedOp(this,number));

    }
}
