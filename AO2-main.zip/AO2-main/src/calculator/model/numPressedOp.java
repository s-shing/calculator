package calculator.model;

import static java.lang.Double.parseDouble;

public class numPressedOp implements State{
        private String num ="";
        private State calc;

        public numPressedOp(State calc, int number){
            this.calc = calc;
            num += number;
        }

        public double displayNumber() {
            return parseDouble(this.num);
        }
        public void clearPressed() {

        }

        public void equalsPressed() {

        }
        @Override
        public void numberPressed(int number) {
            this.num += number;
        }


}
